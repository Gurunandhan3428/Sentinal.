"""SENTINEL simulation engine."""

