"""SENTINEL persistence database layer."""

