"""Vercel Serverless entrypoint exporting the SENTINEL FastAPI ASGI application."""

import os
import sys

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from sentinel.backend.api.main import app  # noqa: E402,F401

